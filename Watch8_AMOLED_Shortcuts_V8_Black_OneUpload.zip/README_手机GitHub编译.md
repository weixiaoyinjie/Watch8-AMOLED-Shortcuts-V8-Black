# V8 GitHub Actions 编译（手机操作）

1. 新建仓库 `Watch8-AMOLED-Shortcuts-V8-Black`。
2. 解压 ZIP，把 `app`、`.github`、`build.gradle.kts`、`settings.gradle.kts`、`gradle.properties` 上传到仓库根目录。
3. 打开仓库 **Actions → Build Galaxy Watch8 V8 APK → Run workflow**。
4. 构建成功后打开 Artifacts → `Watch8-AMOLED-V8-APK`，下载并解压出 `app-debug.apk`。
5. 手表安装 APK。包名没变，若提示与旧版签名冲突需卸载旧版再装，重新添加快捷方式。

目标：表盘仍为八快捷位，已去掉 8 张示例底图；使用原生 Wear OS 快捷编辑，优先显示圆形 App 图标，背景纯黑。
