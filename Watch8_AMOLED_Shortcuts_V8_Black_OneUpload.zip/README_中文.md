# Galaxy Watch8 AMOLED Shortcut V8：纯黑背景 · 原始 App 圆形图标

## 本次修改

- **消除重叠**：从 `watchface.xml` 中彻底删除固定叠在 8 个快捷位置底部的 `tile_1`～`tile_8` 示例图片，以及不再使用的 PNG 文件。
- **保留真实图标**：8 个 ComplicationSlot 继续使用 Wear OS 提供的真实 `SMALL_IMAGE` 或 `MONOCHROMATIC_IMAGE`，不画背景圆盘、示例图案或叠加图形。圆形外观由 App/系统提供的图标决定。
- **精简快捷设置**：各槽只声明 `SMALL_IMAGE MONOCHROMATIC_IMAGE EMPTY`，不再接受文字型快捷/信息小组件。保留原来的 8 个系统添加槽位、`EMPTY` 默认值和系统添加方式。
- **纯黑背景**：`#ff000000` 不变；没有添加任何背景图片。
- **其他不变**：电量、日期、中文星期、时间格式、字体、显示坐标、8 个位置尺寸、点击区、WFF2、包名均沿用 V7。
- **版本号**：versionCode 8，versionName 2.6。

## Wear OS 系统限制

WFF2 只能按数据类型筛选可添加的数据源，**无法强制三星原生选择器只显示「应用快捷方式」一种入口**。已去除文字类数据源，尽可能让选项集中为图标，但仍可能出现其它提供图片的复杂功能数据源。图标最终是否圆形、是否彩色，取决于选中的系统/应用数据源。

## 编译

本 ZIP 的根目录就是 GitHub 仓库根目录，直接解压上传 `app/`、`.github/`、Gradle 文件到新仓库根目录即可。

1. 新建仓库，比如 `Watch8-AMOLED-Shortcuts-V8-Black`。
2. 上传解压后的**文件和文件夹**到仓库根目录（不需要额外外层目录）。
3. 在仓库 Actions → `Build Galaxy Watch8 V8 APK` → `Run workflow`。
4. 在运行结果的 Artifacts 下载 `Watch8-AMOLED-V8-APK`，解压得到 `app-debug.apk`。

保持旧包名以方便在签名一致时覆盖升级；但 GitHub Actions 的默认 debug 签名通常每次构建都不同，签名不一致会拒绝覆盖安装。卸载旧表盘会导致原来添加的快捷方式选择可能丢失，请先记下旧设置；这种情况下需要重设 8 个快捷方式。

**验证范围**：已执行源码 XML 和文件结构检查；需要在 Galaxy Watch8 上安装新 APK 才能最终验证三星系统的快捷选择器与真实图标渲染。
